let handler = async m => m.reply(`
Chat Ke Owmer Dan Konfrimasi Pembayaran Nya :).
`.trim()) // Tambah sendiri kalo mau
handler.help = ['join <linkgc>']
handler.tags = ['premium']
handler.command = /^(join)$/i
handler.owner = false
handler.mods = false
handler.premium = false
handler.group = false
handler.private = true

module.exports = handler
